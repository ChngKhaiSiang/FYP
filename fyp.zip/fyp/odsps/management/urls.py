from django.urls import path
from . import views

urlpatterns = [
    # ... other URL patterns ...

    path('admin_dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('approve_service/<int:service_id>/', views.approve_service, name='approve_service'),
    path('reject_service/<int:service_id>/', views.reject_service, name='reject_service'),
    path('login/', views.logout, name='logout'),
    # ... other URL patterns ...
]
