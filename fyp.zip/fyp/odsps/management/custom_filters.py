from django import template

register = template.Library()

@register.filter
def image_base64(image):
    if image:
        return f"data:image/jpeg;base64,{image.decode('utf-8')}"
    return ''
