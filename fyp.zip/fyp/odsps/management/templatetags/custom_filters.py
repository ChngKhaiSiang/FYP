# custom_filters.py
from django import template
from base64 import b64encode

register = template.Library()

@register.filter
def image_base64(image):
    # Your image to base64 transformation logic here
    return b64encode(image).decode("utf-8")
