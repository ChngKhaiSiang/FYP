from django.shortcuts import render
import mysql.connector as sql

# Create your views here.
un=''
s=''
em=''
pwd=''
ques=''
ans=''


def registeratio(request):
    global un,s,em,pwd,ques,ans
    if request.method=="POST":
        m=sql.connect(host="localhost",user="root",password="chngkhaisiang3509",database="odsps")
        cursor=m.cursor()
        d=request.POST
        for key,value in d.items():
            if key=="username":
                un=value
            if key=="sex":
                s=value
            if key=="email":
                em=value
            if key=="password":
                pwd=value
            if key=="security_question":
                ques=value
            if key=="security_answer":
                ans=value

        c = "insert into users Values('{}', '{}', '{}', '{}', '{}', '{}')".format(un, s, em, pwd, ques, ans)
        cursor.execute(c)
        m.commit()

    return render(request,'login_page.html')