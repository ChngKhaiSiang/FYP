from django.contrib.auth import authenticate, login
from django.contrib.sites.shortcuts import get_current_site
from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from django.template.loader import render_to_string
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.core.mail import send_mail
import mysql.connector as sql
from serviceprovider_register.models import ServiceProvider
from django.http import HttpResponse
from django.urls import reverse
import random
import string

def generate_unique_username(email):
    unique_str = ''.join(random.choices(string.ascii_letters + string.digits, k=6))
    return email + unique_str

def register_service_provider(request):
    error_message = ""  # Initialize the error message

    if request.method == "POST":
        # Retrieve and validate form data
        category = request.POST.get('category')
        name_on_ic = request.POST.get('name_on_ic')
        ic_number = request.POST.get('ic_number')
        sp_security_question = request.POST.get('sp_security_question')
        sp_answer = request.POST.get('sp_answer')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        # Check password complexity
        if not (any(c.isupper() for c in password) and
                any(c.islower() for c in password) and
                any(c.isdigit() for c in password)):
            error_message = "Password must contain at least 1 uppercase letter, 1 lowercase letter, and 1 number."
        elif password != confirm_password:
            error_message = "Password and confirm password do not match."
        else:
            # Rest of your registration logic (if there are no errors)
            try:
                # Generate a unique username
                unique_username = generate_unique_username(email)
                print(f"Unique Username: {unique_username}")

                # Create a new User instance
                user = User(username=unique_username, email=email)
                user.password = password  # Store the plain text password

                # Save the User instance to the database
                user.save()

                print(f"User created with ID: {user.id}")

                # Create a new ServiceProvider instance
                service_provider = ServiceProvider()
                service_provider.user = user  # Associate the ServiceProvider with the User

                # Set the ServiceProvider fields
                service_provider.category = category
                service_provider.name_on_ic = name_on_ic
                service_provider.ic_number = ic_number
                service_provider.sp_security_question = sp_security_question
                service_provider.sp_answer = sp_answer

                service_provider.save()

                print(f"ServiceProvider created with ID: {service_provider.id}")

                # Send confirmation email
                current_site = get_current_site(request)
                mail_subject = 'Activate your service provider account'
                message = render_to_string(
                    'account/confirmation_signup_message.txt',
                    {
                        'user': user,
                        'protocol': 'http',  # Change to 'https' for production
                        'domain': current_site.domain,
                        'uidb64': urlsafe_base64_encode(force_bytes(user.pk)),
                        'token': default_token_generator.make_token(user),
                    }
                )
                # Construct the confirmation link
                confirmation_link = reverse('serviceprovider_register:email_confirmation_sent', 
                                            args=[urlsafe_base64_encode(force_bytes(user.pk)), default_token_generator.make_token(user)])

                print(f"Confirmation link: {confirmation_link}")

                # Send the confirmation email with the confirmation link
                send_mail(mail_subject, message, 'chngkhaisiang0517@gmail.com', [email])

                # Redirect to a page indicating that a confirmation email has been sent
                return render(request, 'email_confirmation_sent.html')

            except Exception as e:
                error_message = str(e)

    return render(request, 'sp_register_page.html', {'error_message': error_message})



# View for handling email confirmation
def email_confirmation_sent(request, uidb64=None, token=None):
    if uidb64 is not None and token is not None:
        try:
            # Decode the UID from the URL
            uid = force_str(urlsafe_base64_decode(uidb64))
            # Retrieve the user based on the UID
            user = User.objects.get(pk=uid)

            # Check if the token is valid
            if default_token_generator.check_token(user, token):
                # Token is valid

                # Retrieve the user's information from the database
                category = user.serviceprovider.category
                name_on_ic = user.serviceprovider.name_on_ic
                ic_number = user.serviceprovider.ic_number
                sp_security_question = user.serviceprovider.sp_security_question
                sp_answer = user.serviceprovider.sp_answer
                email = user.email
                password = user.password  # Retrieve the plain text password

                # Save the information to your MySQL database
                try:
                    connection = sql.connect(
                        host="localhost",
                        user="root",
                        password="chngkhaisiang3509",
                        database="odsps"
                    )
                    cursor = connection.cursor()
                    insert_query = "INSERT INTO provider (category, name_on_ic, ic_number, email, sp_security_question,sp_answer, password) VALUES (%s, %s, %s, %s, %s, %s, %s)"
                    values = (category, name_on_ic, ic_number, email, sp_security_question, sp_answer, password)
                    cursor.execute(insert_query, values)

                    connection.commit()
                    cursor.close()
                    connection.close()
                except Exception as e:
                    print("Database Error:", e)  # Debug
                    return render(request, 'email_confirmation_sent.html', {'error': str(e)})

                # Redirect to a success page
                return render(request, 'login_page.html')

            else:
                # Token is not valid
                return render(request, 'error_page.html', {'error': 'Invalid token'})

        except User.DoesNotExist:
            # User does not exist
            return render(request, 'error_page.html', {'error': 'User does not exist'})
    else:
        return HttpResponse("Invalid confirmation link")

def sp_register_page(request):
    return render(request, 'sp_register_page.html')
    