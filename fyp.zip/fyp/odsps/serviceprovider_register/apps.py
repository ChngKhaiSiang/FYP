from django.apps import AppConfig


class ServiceproviderRegisterConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'serviceprovider_register'
