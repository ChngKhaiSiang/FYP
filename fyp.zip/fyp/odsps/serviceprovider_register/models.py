from django.db import models
from django.contrib.auth.models import User, Group, Permission

class ServiceProvider(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='serviceprovider')
    category = models.CharField(max_length=100)
    name_on_ic = models.CharField(max_length=255)
    ic_number = models.CharField(max_length=20)
    email_confirmed = models.BooleanField(default=False)
    sp_security_question = models.CharField(max_length=100)  # Add the security question field
    sp_answer = models.CharField(max_length=100, default='')
    groups = models.ManyToManyField(Group, related_name='service_providers')
    user_permissions = models.ManyToManyField(Permission, related_name='service_providers')

    def __str__(self):
        return self.user.username
