from django.urls import path
from . import views

app_name = 'serviceprovider_register'

urlpatterns = [
    path('service_register/', views.register_service_provider, name='register_service_provider'),
    path('email_confirmation_sent/<str:uidb64>/<str:token>/', views.email_confirmation_sent, name='email_confirmation_sent'),
    path('', views.sp_register_page, name='sp_register_page'),
    # Add more URL patterns as needed
]
