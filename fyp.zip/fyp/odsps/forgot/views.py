import mysql.connector as sql
from django.shortcuts import render
from django.http import HttpResponse
from mysql.connector import Error

def forgot_password(request):
    error_message = ''

    if request.method == 'POST':
        # Obtain values from the POST request
        email = request.POST.get('email')
        security_question = request.POST.get('security_question')
        security_answer = request.POST.get('security_answer')
        new_password = request.POST.get('new_password')

        try:
            # Establish a database connection
            connection = sql.connect(
                host="localhost",
                user="root",
                password="chngkhaisiang3509",
                database="odsps"
            )
            cursor = connection.cursor()

            # Check if the provided email exists in the users table
            cursor.execute("SELECT * FROM users WHERE Email = %s", (email,))
            user = cursor.fetchone()

            if user:
                # Check if the security question and answer match
                if user[4] == security_question and user[5] == security_answer:
                    # Update the user's password
                    cursor.execute("UPDATE users SET Password = %s WHERE Email = %s", (new_password, email))
                    connection.commit()
                    error_message = "Password reset successful for user."
                else:
                    error_message = "Incorrect security question/answer for the user."

            else:
                # Check if the provided email exists in the provider table
                cursor.execute("SELECT * FROM provider WHERE email = %s", (email,))
                provider = cursor.fetchone()

                if provider:
                    # Check if the security question and answer match
                    if provider[5] == security_question and provider[6] == security_answer:
                        # Update the provider's password
                        cursor.execute("UPDATE provider SET password = %s WHERE email = %s", (new_password, email))
                        connection.commit()
                        error_message = "Password reset successful for provider."
                    else:
                        error_message = "Incorrect security question/answer for the provider."
                else:
                    error_message = "Email not found in the database."

        except Exception as e:
            error_message = 'Fail to reset password'  # Handle and store the error message
        finally:
            # Close the cursor and database connection
            cursor.close()
            connection.close()

    if error_message:
        return render(request, 'login_page.html', {'error_message': error_message})
    else:
        return render(request, 'forgot_page.html', {'error_message': error_message})
