from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
import mysql.connector as sql
from django.contrib import messages
from django.core.files import File
from django.core.files.storage import FileSystemStorage
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse

def addservice(request):
    error_message=None
    if request.method == 'POST':
        if 'user_email' in request.session:  # Check if the user is logged in
            email = request.session['user_email']  # Retrieve user's email from the session
            image = request.FILES['image']
            business_license = request.FILES['business_license']  # Retrieve the uploaded business license image
            category = request.POST['category']
            title = request.POST['title']
            description = request.POST['description']
            city = request.POST['city']

            # Handle the uploaded image
            uploaded_image = request.FILES['image']
            uploaded_license = request.FILES['business_license']
            fs = FileSystemStorage(location='media/services/')
            image_name_bytes = fs.save(uploaded_image.name, uploaded_image)
            license_name_bytes = fs.save(uploaded_license.name, uploaded_license)
            image_name = image_name_bytes
            license_name = license_name_bytes

            # Add some print statements for debugging
            print(f"Email: {email}")
            print(f"Category: {category}")
            print(f"Title: {title}")
            print(f"Description: {description}")

            # Database connection setup
            try:
                connection = sql.connect(
                    host="localhost",
                    user="root",
                    password="chngkhaisiang3509",
                    database="odsps"
                )
                cursor = connection.cursor()
                image_path = f'media/services/{image_name}'
                license_path = f'media/services/{license_name}'

                # Insert data into the 'services' table
                query = "INSERT INTO services (image, business_license, city, category, title, description, status, email) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
                values = (image_name, license_name, city, category, title, description, "Waiting", email)

                cursor.execute(query, values)
                connection.commit()

                connection.close()

                error_message= 'Service added successfully.Wait for approval.'
                return render(request, 'sp_dashboard.html',{'error_message': error_message})
            except sql.Error as e:
                # Handle database errors
                print(f"Database error: {e}")
                error_message='Error adding service. Please try again.'
                return render(request, 'sp_dashboard.html',{'error_message': error_message})
    # Handle the GET request and render the form
    return render(request, 'add_service_page.html',{'error_message': error_message})

def view_user_bookings(request):
    if 'user_email' in request.session:
        email = request.session['user_email']

        # Establish a MySQL database connection
        connection = sql.connect(
            host="localhost",
            user="root",
            password="chngkhaisiang3509",
            database="odsps"
        )
        cursor = connection.cursor()

        # Construct the SQL query to fetch user bookings with priority order
        query = """
        SELECT b.id, b.service_id, b.user_email, b.selected_date, b.selected_time, s.image, b.status ,u.level, u.phone
        FROM bookings AS b
        INNER JOIN services AS s ON b.service_id = s.id
        INNER JOIN users AS u ON b.user_email = u.Email
        WHERE s.email = %s
        AND b.status NOT IN ('rejected', 'Done')
        ORDER BY u.points DESC;
        """
        
        cursor.execute(query, (email,))
        user_bookings_rows = cursor.fetchall()

        # Filter out bookings with status "rejected" and "Done"
        user_bookings = []
        for row in user_bookings_rows:
            user_booking = {
                'booking_id': row[0],
                'service_id': row[1],
                'user_email': row[2],
                'selected_date': row[3],
                'selected_time': row[4],
                'service_image': row[5],
                'status': row[6],
                'level': row[7],
                'phone': row[8],
            }
            user_bookings.append(user_booking)

        # Close the cursor and the database connection
        cursor.close()
        connection.close()

        return render(request, 'sp_view_booking.html', {'user_bookings': user_bookings})
    else:
        return render(request, 'sp_view_booking.html', {'message': 'Service provider not logged in'})

def accept_booking(request, booking_id):
    # Update the booking status to "accepted" in the database

    # Establish a database connection
    connection = sql.connect(
        host="localhost",
        user="root",
        password="chngkhaisiang3509",
        database="odsps"
    )
    cursor = connection.cursor()

    try:
        # Define the SQL update statement
        update_query = "UPDATE bookings SET status = %s WHERE id = %s"
        # Set the status to "accepted"
        status = "accepted"

        # Execute the update query with the status and booking_id
        cursor.execute(update_query, (status, booking_id))
        
        # Commit the changes to the database
        connection.commit()

    except sql.Error as e:
        # Handle any database errors
        print(f"Database error: {e}")
    finally:
        # Close the database connection
        cursor.close()
        connection.close()

    # Redirect to the 'view_user_bookings' page after updating
    return redirect('serviceprovider:view_user_bookings')

from django import forms

class RejectionReasonForm(forms.Form):
    reason = forms.CharField(
        max_length=255,
        required=True,
        widget=forms.Textarea(attrs={'placeholder': 'Enter rejection reason', 'rows': 4}),
    )

def reject_booking(request, booking_id):
    # Establish a database connection
    connection = sql.connect(
        host="localhost",
        user="root",
        password="chngkhaisiang3509",
        database="odsps"
    )
    cursor = connection.cursor()

    if request.method == 'POST':
        # Validate the form
        form = RejectionReasonForm(request.POST)
        if form.is_valid():
            rejection_reason = form.cleaned_data['reason']

            try:
                # Define the SQL update statement
                update_query = "UPDATE bookings SET status = %s, rejection_reason = %s WHERE id = %s"
                # Set the status to "rejected"
                status = "Rejected"

                # Execute the update query with the status, rejection_reason, and booking_id
                cursor.execute(update_query, (status, rejection_reason, booking_id))
                connection.commit()

                # Close the database connection
                cursor.close()
                connection.close()

                return redirect('serviceprovider:view_user_bookings')
            except sql.Error as e:
                # Handle any database errors
                print(f"Database error: {e}")
        else:
            # Form is not valid; you can handle this case accordingly
            pass  # Add the appropriate action here
    else:
        form = RejectionReasonForm()

    # Render the rejection reason form
    return render(request, 'reject_booking.html', {'form': form, 'booking_id': booking_id})


def done_booking(request, booking_id):
    # Update the booking status to "Done" in the database

    # Establish a database connection
    connection = sql.connect(
        host="localhost",
        user="root",
        password="chngkhaisiang3509",
        database="odsps"
    )
    cursor = connection.cursor()

    try:
        # Define the SQL update statement
        update_query = "UPDATE bookings SET status = %s WHERE id = %s"
        # Set the status to "Done"
        status = "Done"

        # Execute the update query with the status and booking_id
        cursor.execute(update_query, (status, booking_id))

        # Commit the changes to the database
        connection.commit()

        # Get the user_email associated with the booking
        user_email = fetch_user_email_for_booking(booking_id)

        # Call the function to update membership and points with the user_email
        update_membership_and_points(user_email)

    except sql.Error as e:
        # Handle any database errors
        print(f"Database error: {e}")
    finally:
        # Close the database connection
        cursor.close()
        connection.close()

    # Redirect to the 'view_user_bookings' page after updating
    return redirect('serviceprovider:view_user_bookings')

def update_membership_and_points(user_email):
    connection = sql.connect(
        host="localhost",
        user="root",
        password="chngkhaisiang3509",
        database="odsps"
    )
    cursor = connection.cursor()

    # Assuming you have a users table with columns 'email', 'level', and 'points'.
    # No need to fetch user_email here, it's passed as an argument

    # Rest of the function remains the same
    sql_query = "SELECT level, points FROM users WHERE Email = %s"
    cursor.execute(sql_query, (user_email,))
    user_data = cursor.fetchone()

    if user_data:
        current_level, current_points = user_data
        # Increment the user's points when booking is done
        new_points = current_points + 10

        # Check for membership level upgrades
        new_level = current_level
        if new_points >= 300:
            new_level = 3
        elif new_points >= 100:
            new_level = 2

        # Update the user's membership level and points
        update_query = "UPDATE users SET level = %s, points = %s WHERE Email = %s"
        update_values = (new_level, new_points, user_email)

        cursor.execute(update_query, update_values)
        connection.commit()

    cursor.close()
    connection.close()

def fetch_user_email_for_booking(booking_id):
    try:
        connection = sql.connect(
            host="localhost",
            user="root",
            password="chngkhaisiang3509",
            database="odsps"
        )
        cursor = connection.cursor()

        # Fetch the user_email associated with the booking_id
        query = "SELECT user_email FROM bookings WHERE id = %s"
        cursor.execute(query, (booking_id,))
        result = cursor.fetchone()

        if result:
            user_email = result[0]
        else:
            user_email = None  # Handle cases where the booking_id is not found

        cursor.close()
        connection.close()

        return user_email

    except sql.Error as e:
        # Handle database errors
        print(f"Database error: {e}")
        return None  # Handle the error gracefully
    

def back(request, user_email):
    services = []  # Initialize an empty list to store service dictionaries

    try:
        connection = sql.connect(
            host="localhost",
            user="root",
            password="chngkhaisiang3509",
            database="odsps"
        )
        cursor = connection.cursor()

        # Build the SQL query to select services based on the email
        query = f"SELECT * FROM services WHERE email = '{user_email}'"
        cursor.execute(query)

        service_rows = cursor.fetchall()

        for row in service_rows:
            service = {
                'title': row[3],  # Adjust these indexes based on your database structure
                'description': row[4],
                'category': row[2],
                'status': row[5],
                'image': row[1],  # If the image URL is stored in the database
                'reason': row[11],
            }
            services.append(service)

        cursor.close()
        connection.close()

        return render(request, 'sp_dashboard.html', {'services': services})

    except Exception as e:
        error_message = str(e)
        messages.error(request, error_message)
        return render(request, 'login_page.html', {'error_message': error_message})

def logout(request):
    return render(request, 'login_page.html')