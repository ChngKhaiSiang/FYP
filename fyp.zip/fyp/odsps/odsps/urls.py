from django.contrib import admin
from django.urls import path, include
from login.views import registeration
from login.views import login
from homepage.views import search
from serviceprovider_register.views import register_service_provider
from serviceprovider import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('login.urls')),
    path('register/', registeration,name='register'),
    
    path('login/', login,name='login'),
    path('homepage/', search),
    
    path('accounts/', include('allauth.urls')),
    path('login/serviceregister/', include('serviceprovider_register.urls')),
    path('management/', include('management.urls')),
    path('user/', include('user.urls')),
    path('serviceprovider/', include('serviceprovider.urls', namespace='serviceprovider')),
    path('forgot/', include('forgot.urls', namespace='forgot')), 
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
