from django.shortcuts import render, redirect
import mysql.connector as sql
from django.contrib import messages

def sp_service(request, email):
    services = []  # Initialize an empty list to store service dictionaries

    try:
        connection = sql.connect(
            host="localhost",
            user="root",
            password="chngkhaisiang3509",
            database="odsps"
        )
        cursor = connection.cursor()

        query = f"SELECT * FROM services WHERE email = '{email}'"
        cursor.execute(query)

        service_rows = cursor.fetchall()

        for row in service_rows:
            service = {
                'title': row[3],  # Adjust these indexes based on your database structure
                'description': row[4],
                'category': row[2],
                'status': row[5],
                'image': row[1],  # If the image URL is stored in the database
                'reason': row[11],
            }
            services.append(service)

        cursor.close()
        connection.close()

        return render(request, 'sp_dashboard.html', {'services': services})

    except Exception as e:
        error_message = str(e)
        messages.error(request, error_message)
        return render(request, 'login_page.html', {'error_message': error_message})

def login(request):
    error_message = None

    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")

        try:
            connection = sql.connect(
                host="localhost",
                user="root",
                password="chngkhaisiang3509",
                database="odsps"
            )
            cursor = connection.cursor()

            cursor.execute("SELECT * FROM users WHERE email = %s AND password = %s", (email, password))
            user_data = cursor.fetchone()
            
            cursor.execute("SELECT * FROM provider WHERE email = %s AND password = %s", (email, password))
            sp_data = cursor.fetchone()

            cursor.close()
            connection.close()

            if user_data:
                request.session['user_email'] = email
                print("User email set in session:", email)
                return showinfo(request, email)
                
            elif sp_data:
                request.session['user_email'] = email
                # Call the sp_service functionality here
                return sp_service(request, email)
            elif email == "admin@gmail.com" and password == "admin":
                return redirect('admin_dashboard')
            else:
                error_message = "No matching user found"
        
        except Exception as e:
            error_message = "An error occurred: " + str(e)
    
    return render(request, 'login_page.html', {'error_message': error_message})


def registeration(request):
    error_message = None  # Initialize error message

    if request.method == "POST":
        password = request.POST.get("password")
        confirm_password = request.POST.get("confirm_password")

        if not (any(c.isupper() for c in password) and
                any(c.islower() for c in password) and
                any(c.isdigit() for c in password)):
            error_message = "Password must contain at least 1 uppercase letter, 1 lowercase letter, and 1 number."

        if password != confirm_password:
            error_message = "Password and confirm password do not match."

        if not error_message:
            try:
                # Connect to the MySQL database
                connection = sql.connect(
                    host="localhost",
                    user="root",
                    password="chngkhaisiang3509",
                    database="odsps"
                )
                cursor = connection.cursor()

                username = request.POST.get("username")
                sex = request.POST.get("sex")
                email = request.POST.get("email")
                phone = request.POST.get("phone")
                security_question = request.POST.get("security_question")
                security_answer = request.POST.get("security_answer")

                c = "INSERT INTO users (Username, Sex, Email, Password, security_question, security_answer, phone) " \
                    "VALUES (%s, %s, %s, %s, %s, %s, %s)"
                cursor.execute(c, (username, sex, email, password, security_question, security_answer, phone))
                error_message="Register Successfully"
                connection.commit()
            except Exception as e:
                # Handle any exceptions, e.g., database errors
                print("Error:", str(e))
                error_message = "An error occurred while registering."

            finally:
                cursor.close()
                connection.close()

    return render(request, 'login_page.html', {'error_message': error_message})

def showinfo(request, email):
    try:
        connection = sql.connect(
            host="localhost",
            user="root",
            password="chngkhaisiang3509",
            database="odsps"
        )

        # Build the SQL query to select all services (without filtering)
        query = "SELECT s.*, COUNT(CASE WHEN b.status IN ('Done' ,'Done Rating') THEN 1 ELSE NULL END) AS bookings_count FROM services s"
        query += " LEFT JOIN bookings b ON s.id = b.service_id"
        query += " WHERE s.status = 'Approve'"  # Only approved services
        query += " GROUP BY s.id"

        cursor = connection.cursor()
        cursor.execute(query)
        service_rows = cursor.fetchall()
        services = []

        # Unpack the tuples into dictionaries
        for row in service_rows:
            service_id = row[0]
            service_status = row[6]
            # 'bookings_count' is now available in the result
            bookings_count = row[12]
            service = {
                'id': service_id,
                'image': row[1],
                'category': row[2],
                'title': row[3],
                'description': row[4],
                'average_rating': row[9],
                'status': service_status,
                'email': row[7],
                'created_at': row[8],
                'bookings_count': bookings_count,
            }
            services.append(service)

        cursor.close()
        connection.close()

        # Fetch the user's favorite service IDs and pass them to the template context
        user_favorites = get_user_favorites(request)
        user_email = request.session.get('user_email', None)

        context = {
            'services': services,
            'user_favorites': user_favorites,
            'user_email': user_email,
        }

        # Debugging: Print the generated SQL query
        print("Generated SQL Query:", query)

        return render(request, 'user_page.html', context)

    except sql.Error as e:
        # Handle database errors
        print(f"Database error: {e}")
        return None  # Handle the error as needed

def get_user_favorites(request):
    # Implement this function to fetch the user's favorite service IDs
    # use the user's identifier or email from the session to fetch their favorites from the database.
    # For example:
    user_email = request.session.get('user_email', None)
    if user_email:
        # Connect to the database and fetch user's favorites
        try:
            connection = sql.connect(
                host="localhost",
                user="root",
                password="chngkhaisiang3509",
                database="odsps"
            )
            cursor = connection.cursor()
            cursor.execute("SELECT service_id FROM user_favourites WHERE user_email = %s", (user_email,))
            user_favourites = {row[0] for row in cursor.fetchall()}
            cursor.close()
            connection.close()
            return user_favourites
        except sql.Error as e:
            print(f"Database error: {e}")
    return set()

def home_page(request):
    return render(request, 'home_page.html')

def service_page(request):
    return render(request, 'service.html')

def contact_page(request):
    return render(request, 'contact.html')

