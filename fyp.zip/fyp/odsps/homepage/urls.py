from django.urls import path
from . import views

urlpatterns = [
    path('search/', views.search, name='search'),
    path('service_details/<int:service_id>/', views.service_details, name='service_details'),
]
