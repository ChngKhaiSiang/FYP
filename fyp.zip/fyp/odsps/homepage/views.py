from django.shortcuts import render
from .models import Service  # Assuming you have a Service model

def search(request):
    services = Service.objects.all()

    # Handle search query
    search_query = request.GET.get('search', '')
    if search_query:
        services = services.filter(name__icontains=search_query)

    # Handle city filter
    selected_city = request.GET.get('city', '')
    if selected_city:
        services = services.filter(city=selected_city)

    # Other context data and rendering logic
    return render(request, 'home_page.html', {'services': services})

