from django.db import models

class Service(models.Model):
    name = models.CharField(max_length=255)
    city = models.CharField(max_length=100)
    # Other fields and methods if applicable
