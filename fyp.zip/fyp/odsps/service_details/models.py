from django.db import models

class Service(models.Model):
    pass
