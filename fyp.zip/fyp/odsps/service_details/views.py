from django.shortcuts import render, get_object_or_404
from .models import Service

def service_details(request, service_id):
    service = get_object_or_404(Service, pk=service_id)
    # Add your logic here
    return render(request, 'service_details.html', {'service': service})
