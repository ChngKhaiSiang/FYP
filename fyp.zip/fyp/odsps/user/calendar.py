from schedule.models import Calendar

def create_booking_calendar():
    # Create a new calendar for booking
    booking_calendar, created = Calendar.objects.get_or_create(name="Booking Calendar")
    return booking_calendar