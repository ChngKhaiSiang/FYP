import mysql.connector as sql
from django.shortcuts import render, redirect

def admin_dashboard(request):
    # Connect to the MySQL database
    connection = sql.connect(
        host="localhost",
        user="root",
        password="chngkhaisiang3509",
        database="odsps"
    )
    cursor = connection.cursor()

    # Fetch services with pending status (assuming 'status' is a boolean field)
    cursor.execute("SELECT * FROM services WHERE status = 'Waiting' AND id IS NOT NULL")
    
    # Fetch all rows as tuples
    service_rows = cursor.fetchall()

    # Create a list of dictionaries to store the services
    services = []

    # Unpack the tuples into dictionaries
    for row in service_rows:
        service = {
            'id': row[0],        # 'id' is the first column in the table
            'image': row[1],
            'category': row[2],
            'title': row[3],
            'description': row[4],
            'status': row[5],
            'email': row[6],
            'created_at': row[7],
            'city':row[8],
            'business_license': row[10]
        }
        services.append(service)

    cursor.close()
    connection.close()

    return render(request, 'admin_dashboard.html', {'services': services})


def approve_service(request, service_id):
    # Connect to the MySQL database
    connection = sql.connect(
        host="localhost",
        user="root",
        password="chngkhaisiang3509",
        database="odsps"
    )
    cursor = connection.cursor()

    # Update the status to 'approved' (1) for the specified service
    cursor.execute("UPDATE services SET status = 'Approve' WHERE id = %s", (service_id,))
    connection.commit()

    cursor.close()
    connection.close()

    return redirect('admin_dashboard')

from django import forms


class RejectionReasonForm(forms.Form):
    reason = forms.CharField(
        max_length=255,
        required=True,
        widget=forms.Textarea(attrs={'placeholder': 'Enter reject reason', 'rows': 4}),
    )


def reject_service(request, service_id):
    if request.method == 'POST':
        # Validate the form
        form = RejectionReasonForm(request.POST)
        if form.is_valid():
            rejection_reason = form.cleaned_data['reason']
            
            # Connect to the MySQL database
            connection = sql.connect(
                host="localhost",
                user="root",
                password="chngkhaisiang3509",
                database="odsps"
            )
            cursor = connection.cursor()

            # Update the status and reason for the specified service
            cursor.execute("UPDATE services SET status = 'Rejected', reason = %s WHERE id = %s", (rejection_reason, service_id))
            connection.commit()

            cursor.close()
            connection.close()

            return redirect('admin_dashboard')
    else:
        form = RejectionReasonForm()

    return render(request, 'reject_service.html', {'form': form})

def logout(request):
    return render(request, 'login_page.html')