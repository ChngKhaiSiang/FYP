from django.shortcuts import render,redirect
import mysql.connector as sql
from schedule.models import Event
from .calendar import create_booking_calendar
import datetime
from django.http import HttpResponse
import pytz


def user_search(request):
    context = {}
    if request.method == 'GET':
        city = request.GET.get('city', 'all')
        category = request.GET.get('category', 'all')
        search_title = request.GET.get('title', '')
        sort_option = request.GET.get('sort', 'relevant')  # Get the user's sorting preference

        try:
            connection = sql.connect(
                host="localhost",
                user="root",
                password="chngkhaisiang3509",
                database="odsps"
            )

            # Build the base SQL query
            query = "SELECT s.*, COUNT(CASE WHEN b.status IN ('Done' ,'Done Rating') THEN 1 ELSE NULL END) AS bookings_count FROM services s"
            query += " LEFT JOIN bookings b ON s.id = b.service_id"
            query += " WHERE s.status = 'Approve'"  # Only approved services

            if city != 'all':
                query += f" AND s.city = '{city}'"
            if category != 'all':
                query += f" AND s.category = '{category}'"
            if search_title:
                query += f" AND s.title LIKE '%{search_title}%'"

            query += " GROUP BY s.id"  # Group services to count bookings

            if sort_option == 'rating_high_to_low':
                query += " ORDER BY average_rating DESC"
            elif sort_option == 'most_bookings':
                query += " ORDER BY bookings_count DESC"  # Sort by most bookings
            else:
                query += " ORDER BY created_at DESC"  # Default sorting

            cursor = connection.cursor()
            cursor.execute(query)
            service_rows = cursor.fetchall()
            services = []

            # Unpack the tuples into dictionaries
            for row in service_rows:
                service_id = row[0]
                service_status = row[6]
                # 'bookings_count' is now available in the result
                bookings_count = row[12]
                service = {
                    'id': service_id,
                    'image': row[1],
                    'category': row[2],
                    'title': row[3],
                    'description': row[4],
                    'average_rating': row[9],
                    'status': service_status,
                    'email': row[7],
                    'created_at': row[8],
                    'bookings_count': bookings_count,
                }
                services.append(service)

            cursor.close()
            connection.close()

            # Fetch the user's favorite service IDs and pass them to the template context
            user_favorites = get_user_favorites(request)
            user_email = request.session.get('user_email', None)

            context = {
                'services': services,
                'user_favorites': user_favorites,
                'user_email': user_email,
            }

            # Debugging: Print the generated SQL query
            print("Generated SQL Query:", query)

        except sql.Error as e:
            # Handle database errors
            print(f"Database error: {e}")
            services = []

        return render(request, 'user_page.html', context)


def get_user_favorites(request):
    # Implement this function to fetch the user's favorite service IDs
    # use the user's identifier or email from the session to fetch their favorites from the database.
    # For example:
    user_email = request.session.get('user_email', None)
    if user_email:
        # Connect to the database and fetch user's favorites
        try:
            connection = sql.connect(
                host="localhost",
                user="root",
                password="chngkhaisiang3509",
                database="odsps"
            )
            cursor = connection.cursor()
            cursor.execute("SELECT service_id FROM user_favourites WHERE user_email = %s", (user_email,))
            user_favourites = {row[0] for row in cursor.fetchall()}
            cursor.close()
            connection.close()
            return user_favourites
        except sql.Error as e:
            print(f"Database error: {e}")
    return set()

def add_remove_favourite(request, service_id):
    # identify the user in a way that suits your application.
    # For this example, I'm using a unique identifier, such as a session ID.
    # can replace this with own user identification mechanism.
    print("Starting add_remove_favorite view")
    user_email = request.session.get('user_email', None)  # Using a session email as an example

    if user_email is not None:
        connection = sql.connect(
            host="localhost",
            user="root",
            password="chngkhaisiang3509",
            database="odsps"
        )
        cursor = connection.cursor()
        print("yes")
        # Check if the service is already a favorite for the user
        query = "SELECT * FROM user_favourites WHERE user_email = %s AND service_id = %s"
        cursor.execute(query, (user_email, service_id))
        result = cursor.fetchone()

        if result:
            # Service is a favorite, so remove it
            query = "DELETE FROM user_favourites WHERE user_email = %s AND service_id = %s"
            cursor.execute(query, (user_email, service_id))
        else:
            # Service is not a favorite, so add it
            query = "INSERT INTO user_favourites (user_email, service_id) VALUES (%s, %s)"
            cursor.execute(query, (user_email, service_id))

        connection.commit()
        cursor.close()
        connection.close()

    return render(request,'user_page.html')


def book_service(request, service_id):
    error_message=None
    if request.method == 'POST':
        service_id = request.POST['service_id']
        user_email = request.POST['user_email']
        selected_date = request.POST['selected_date']
        selected_time = request.POST['selected_time']

        try:
            # Create a booking calendar
            booking_calendar = create_booking_calendar()

            # Calculate the end time of the booking (e.g., 1-hour duration)
            selected_date = datetime.datetime.strptime(selected_date, "%Y-%m-%d")
            start_time = selected_date.replace(
                hour=int(selected_time.split(':')[0]),
                minute=int(selected_time.split(':')[1]),
                tzinfo=pytz.UTC  # Set the timezone, adjust as needed
            )
            end_time = start_time + datetime.timedelta(hours=1)
            end_time = end_time.replace(tzinfo=pytz.UTC)  # Set the timezone, adjust as needed

            # Retrieve the service image URL based on the 'service_id'
            connection = sql.connect(
                host="localhost",
                user="root",
                password="chngkhaisiang3509",
                database="odsps"
            )
            cursor = connection.cursor()

            # Retrieve the service image URL
            service_image_query = "SELECT image FROM services WHERE id = %s"
            cursor.execute(service_image_query, (service_id,))
            service_image_row = cursor.fetchone()

            if service_image_row:
                service_image = service_image_row[0]
            else:
                service_image = ""  # Set a default value if service_id is not found

            cursor.close()
            connection.close()

            # Create a new booking event
            event = Event(
                calendar=booking_calendar,
                title=f"Service {service_id} Booking",
                description=f"Booked by {user_email}",
                start=start_time,
                end=end_time,
            )
            event.save()

            # Insert the booking details into the 'bookings' table using SQL
            connection = sql.connect(
                host="localhost",
                user="root",
                password="chngkhaisiang3509",
                database="odsps"
            )
            cursor = connection.cursor()

            # Insert the booking details into the 'bookings' table
            sql_query = "INSERT INTO bookings (service_id, user_email, selected_date, selected_time, service_image, status) VALUES (%s, %s, %s, %s, %s, %s)"
            sql_values = (service_id, user_email, selected_date, selected_time, service_image, 'Waiting')

            cursor.execute(sql_query, sql_values)
            connection.commit()
            cursor.close()
            connection.close()
            error_message="Booking successful"
        except Exception as e:
            # Handle booking errors
            error_message = "Booking fail : "+str(e)
    # Handle GET request or form submission errors
    return render(request, 'user_page.html',{'error_message': error_message})


def favourites(request):
    if request.method == 'GET':
        user_email = request.session.get('user_email', None)

        if user_email:
            try:
                connection = sql.connect(
                    host="localhost",
                    user="root",
                    password="chngkhaisiang3509",
                    database="odsps"
                )

                # Query the database to retrieve the user's favorite services
                query = """
                    SELECT s.* 
                    FROM services s
                    INNER JOIN user_favourites uf ON s.id = uf.service_id
                    WHERE uf.user_email = %s
                """

                cursor = connection.cursor()
                cursor.execute(query, (user_email,))
                favourite_services_rows = cursor.fetchall()

                favourite_services = []

                # Unpack the tuples into dictionaries
                for row in favourite_services_rows:
                    service = {
                        'id': row[0],
                        'image': row[1],
                        'category': row[2],
                        'title': row[3],
                        'description': row[4],
                        'status': row[5],
                        'email': row[6],
                        'created_at': row[7],
                    }
                    favourite_services.append(service)

                cursor.close()
                connection.close()

                return render(request, 'favourites.html', {'favourite_services': favourite_services})

            except sql.Error as e:
                # Handle database errors
                print(f"Database error: {e}")

    # Redirect to the user page or an error page if there was a problem
    return render(request,'user_page.html')


def remove_from_favourites(request, service_id):
    user_email = request.session.get('user_email', None)

    if user_email:
        connection = sql.connect(
            host="localhost",
            user="root",
            password="chngkhaisiang3509",
            database="odsps"
        )
        cursor = connection.cursor()

        # Remove the service from favourites
        query = "DELETE FROM user_favourites WHERE user_email = %s AND service_id = %s"
        cursor.execute(query, (user_email, service_id))
        connection.commit()

        cursor.close()
        connection.close()

    return render(request,'user_page.html')

def user_view_booking(request):
    if 'user_email' in request.session:
        user_email = request.session['user_email']

        # Connect to the MySQL database
        connection = sql.connect(
            host="localhost",
            user="root",
            password="chngkhaisiang3509",
            database="odsps"
        )
        cursor = connection.cursor()

        # Fetch bookings for the user with matching email
        cursor.execute("SELECT service_image, selected_date, selected_time, status, service_id, id, rejection_reason FROM bookings WHERE user_email = %s ORDER BY id DESC", (user_email,))
        booking_rows = cursor.fetchall()

        # Create a list of dictionaries to store the bookings
        bookings = []

        for row in booking_rows:
            booking = {
                'service_image': row[0],
                'selected_date': row[1],
                'selected_time': row[2],
                'status': row[3],
                'service_id': row[4],
                'id' : row[5],
                'rejection_reason' : row[6],
            }
            bookings.append(booking)

        cursor.close()
        connection.close()

        return render(request, 'user_view_booking.html', {'bookings': bookings, 'user_email': user_email})

    return HttpResponse("User not logged in.")

def rating_page(request, service_id, booking_id):
    if request.method == 'POST':
        # Get the rating and comment from the POST request
        rating = request.POST.get('rating')
        comment = request.POST.get('comment')

        # Insert the rating and comment into the rating table
        connection = sql.connect(
            host="localhost",
            user="root",
            password="chngkhaisiang3509",
            database="odsps"
        )
        cursor = connection.cursor()
        insert_query = "INSERT INTO rating (service_id, rating, comment) VALUES (%s, %s, %s)"
        values = (service_id, rating, comment)

        try:
            cursor.execute(insert_query, values)
            connection.commit()
            cursor.close()
            connection.close()

            # After inserting the rating, recalculate the average and update the 'services' table
            update_average_rating(service_id)

            # Update the 'bookings' table to set the status to 'Done Rating'
            update_booking_status(booking_id, 'Done Rating')

            return render(request, 'rating_success.html')
        except Exception as e:
            return HttpResponse('Error: ' + str(e))

    # Render the HTML page with the rating form
    return render(request, 'rating_page.html')

def update_booking_status(booking_id, new_status):
    # Connect to the database
    connection = sql.connect(
        host="localhost",
        user="root",
        password="chngkhaisiang3509",
        database="odsps"
    )
    cursor = connection.cursor()

    # Update the status in the 'bookings' table
    update_query = "UPDATE bookings SET status = %s WHERE id = %s"
    values = (new_status, booking_id)

    try:
        cursor.execute(update_query, (new_status, booking_id))
        connection.commit()
    except Exception as e:
        # Handle the error as needed
        print('Error updating booking status:', str(e))
    finally:
        cursor.close()
        connection.close()

def update_average_rating(service_id):
    connection = sql.connect(
        host="localhost",
        user="root",
        password="chngkhaisiang3509",
        database="odsps"
    )
    cursor = connection.cursor()

    # SQL query to calculate the average rating for the specified service_id
    average_query = "SELECT AVG(rating) FROM rating WHERE service_id = %s"
    cursor.execute(average_query, (service_id,))
    average_rating = cursor.fetchone()[0]  # Fetch the average rating

    # Update the 'services' table with the calculated average rating
    update_query = "UPDATE services SET average_rating = %s WHERE id = %s"
    cursor.execute(update_query, (average_rating, service_id))
    connection.commit()

    cursor.close()
    connection.close()

def comments_page(request, service_id):
    # Establish a database connection
    connection = sql.connect(
        host="localhost",
        user="root",
        password="chngkhaisiang3509",
        database="odsps"
    )
    cursor = connection.cursor()

    # Retrieve ratings and comments for the specified service_id
    select_query = "SELECT rating, comment FROM rating WHERE service_id = %s"
    cursor.execute(select_query, (service_id,))
    ratings_and_comments = cursor.fetchall()

    # Close the database connection
    cursor.close()
    connection.close()

    return render(request, 'comments_page.html', {'ratings_and_comments': ratings_and_comments})

def count_done_bookings(service_id):
    try:
        connection = sql.connect(
            host="localhost",
            user="root",
            password="chngkhaisiang3509",
            database="odsps"
        )
        cursor = connection.cursor()

        # Count 'Done' bookings for the service
        query = "SELECT COUNT(*) FROM bookings WHERE service_id = %s AND (status = 'Done' OR status = 'Done Rating')"
        cursor.execute(query, (service_id,))
        done_bookings_count = cursor.fetchone()[0]

        cursor.close()
        connection.close()

        return done_bookings_count
    except sql.Error as e:
        print(f"Database error: {e}")
        return 0  # Handle database error gracefully

def subscribe_page(request):
    user_email = request.session.get('user_email')
    connection = sql.connect(
        host="localhost",
        user="root",
        password="chngkhaisiang3509",
        database="odsps"
    )
    cursor = connection.cursor()

    # Check the user's membership level and points from the database
    sql_query = "SELECT level, points FROM users WHERE Email = %s"
    cursor.execute(sql_query, (user_email,))
    user_data = cursor.fetchone()
    if user_data:
        membership_level, user_points = user_data

    cursor.close()
    connection.close()

    return render(request, 'subscribe_page.html', {
        'level': membership_level,
        'points': user_points,
    })


def subscribe(request):
    if request.method == 'POST':
        user_email = request.session.get('user_email')
        connection = sql.connect(
            host="localhost",
            user="root",
            password="chngkhaisiang3509",
            database="odsps"
        )
        cursor = connection.cursor()

        # Check the user's membership level from the database
        sql_query = "SELECT level FROM users WHERE Email = %s"
        cursor.execute(sql_query, (user_email,))
        user_data = cursor.fetchone()
        if user_data:
            membership_level = user_data[0]

            if membership_level == 0:
                # Update the user's membership level in the database
                update_query = "UPDATE users SET level = %s WHERE Email = %s"
                update_values = (1, user_email)
                cursor.execute(update_query, update_values)
                connection.commit()

                # Update the user's session with the new membership level
                request.session['membership_level'] = 1

        cursor.close()
        connection.close()

        # Redirect to subscribe_page with a GET request to display the updated information
        return subscribe_page(request)

    # Handle the GET request to display user information
    user_email = request.session.get('user_email')
    membership_level = request.session.get('membership_level', 0)
    user_points = request.session.get('user_points', 0)

    return render(request, 'subscribe_page.html', {
        'level': membership_level,
        'points': user_points,
        'email': user_email,
    })

from django.shortcuts import render
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from matplotlib import pyplot as plt
from io import BytesIO
import base64
from wordcloud import WordCloud

def analysis(service_id):
    connection = sql.connect(
        host="localhost",
        user="root",
        password="chngkhaisiang3509",
        database="odsps"
    )
    cursor = connection.cursor()

    cursor.execute("SELECT service_id, rating, comment FROM rating WHERE service_id = %s", (service_id,))
    rating_data = cursor.fetchall()

    cursor.execute("SELECT COUNT(*) as done_count FROM bookings WHERE service_id = %s AND (status = 'Done' OR status = 'Done Rating')", (service_id,))
    done_count_data = cursor.fetchall()
    done_count = done_count_data[0][0] if done_count_data else 0

    rating_df = pd.DataFrame(rating_data, columns=['service_id', 'rating', 'comment'])

    rating_df['comment'] = rating_df['comment'].str.lower().str.replace(r'[^\w\s]', '', regex=True)

    if rating_df['comment'].empty:
        return None, None, None

    tfidf_vectorizer = TfidfVectorizer(max_features=1000)
    comment_features = tfidf_vectorizer.fit_transform(rating_df['comment'])

    X = pd.concat([pd.Series(done_count, name='done_count'), rating_df[['rating']], pd.DataFrame(comment_features.toarray())], axis=1)
    X.columns = X.columns.astype(str)

    imputer = SimpleImputer(strategy='constant', fill_value=0)
    numeric_columns = ['done_count', 'rating']
    text_columns = [col for col in X.columns if col not in numeric_columns]

    X[numeric_columns] = imputer.fit_transform(X[numeric_columns])
    X_bool = ~X[numeric_columns].eq(0).all(axis=1)
    X = X[X_bool]

    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X, rating_df['rating'])

    connection.close()

    return model, done_count, imputer

def analysis_view(request, service_id):
    model, done_count, imputer = analysis(service_id)
    error_message = None

    if model is None:
        error_message = "No Done Booking Yet"
        return render(request, 'user_page.html', {'error_message': error_message})

    connection = sql.connect(
        host="localhost",
        user="root",
        password="chngkhaisiang3509",
        database="odsps"
    )
    cursor = connection.cursor()
    cursor.execute("SELECT rating, comment FROM rating WHERE service_id = %s", (service_id,))
    data = cursor.fetchall()
    connection.close()

    data_df = pd.DataFrame(data, columns=['rating', 'comment'])
    data_df['comment'] = data_df['comment'].str.lower().str.replace(r'[^\w\s]', '', regex=True)

    tfidf_vectorizer = TfidfVectorizer(max_features=1000)
    comment_features = tfidf_vectorizer.fit_transform(data_df['comment'])

    X = pd.concat([pd.Series([done_count] * len(data_df), name='done_count'), data_df[['rating']], pd.DataFrame(comment_features.toarray())], axis=1)
    X.columns = X.columns.astype(str)

    numeric_columns = ['done_count', 'rating']
    X[numeric_columns] = imputer.transform(X[numeric_columns])
    X_bool = ~X[numeric_columns].eq(0).all(axis=1)
    X = X[X_bool]

    # Use the trained model to predict ratings
    predicted_ratings = model.predict(X)

    # Generate the word cloud
    wordcloud = WordCloud(width=800, height=400, background_color='white').generate(" ".join(data_df['comment']))

    # Save the word cloud as an image
    wordcloud.to_file('wordcloud.png')

    # Encode the Word Cloud image as base64
    with open('wordcloud.png', 'rb') as wordcloud_image:
        wordcloud_base64 = base64.b64encode(wordcloud_image.read()).decode('utf-8')

    plt.scatter(X['done_count'], predicted_ratings, color='blue')
    plt.xlabel('Done Count')
    plt.ylabel('Predicted Rating')
    plt.title('Relationship between Done Count and Predicted Rating for Service ID ' + str(service_id))

    image_stream = BytesIO()
    plt.savefig(image_stream, format='png')
    image_stream.seek(0)
    chart_data = base64.b64encode(image_stream.read()).decode('utf-8')
    plt.close()

    # Calculate recommendation marks based on predicted ratings and a threshold (e.g., predicted_rating >= 4.0)
    recommendation_threshold = 3.5
    positive_reviews = data_df[predicted_ratings >= recommendation_threshold]
    recommendation_marks = len(positive_reviews)

    # Calculate the mean of predicted ratings
    predicted_ratings_mean = predicted_ratings.mean()

    return render(request, 'analysis_result.html', {
        'result_chart': chart_data,
        'recommendation_marks': recommendation_marks,
        'predicted_ratings_mean': predicted_ratings_mean,
        'wordcloud_base64': wordcloud_base64
    })

def logout(request):
    return render(request, 'login_page.html')

def back(request):
    return render(request, 'user_page.html')