from django.urls import path
from . import views

app_name = 'user'

urlpatterns = [
    path('user_page/', views.user_search, name='user_page'),
    path('user_search/', views.user_search, name='user_search'),
    path('add_remove_favourite/<int:service_id>/', views.add_remove_favourite, name='add_remove_favourite'),
    path('book_service/<int:service_id>/', views.book_service, name='book_service'),
    path('favourites/', views.favourites, name='favourites'),
    path('remove_from_favourites/<int:service_id>/', views.remove_from_favourites, name='remove_from_favourites'),
    path('user_view_booking/', views.user_view_booking, name='user_view_booking'),
    path('rating_page/<int:service_id>/<int:booking_id>/', views.rating_page, name='rating_page'),
    path('comments/<int:service_id>/', views.comments_page, name='comments_page'),
    path('subscribe/', views.subscribe_page, name='subscribe_page'),
    path('analysis/<int:service_id>/', views.analysis_view, name='analysis'),
    path('login/', views.logout, name='logout'),
    path('back', views.back, name='back'),
    path('subscribemember/', views.subscribe, name='subscribe'),
]

