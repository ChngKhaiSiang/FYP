from django.urls import path
from . import views
from .views import accept_booking, reject_booking , done_booking
from .views import view_user_bookings

app_name = 'serviceprovider'

urlpatterns = [
    path('add_service/', views.addservice, name='add_service_page'),
    path('sp_view_booking/', view_user_bookings, name='view_user_bookings'),
    path('accept_booking/<int:booking_id>/', accept_booking, name='accept_booking'),
    path('reject_booking/<int:booking_id>/', reject_booking, name='reject_booking'),
    path('done_booking/<int:booking_id>/', done_booking, name='done_booking'),
    path('login/', views.logout, name='logout'),
    path('serviceprovider/back/<str:user_email>/', views.back, name='back'),
]